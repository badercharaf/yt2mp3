# youtube-to-mp3-api
Convert &amp; Download single video or multiple Youtube videos in Mp3 format using our youtube to mp3 API. Multiple Embedding features are supported like html link, javascript, iframe. Its free also provide affiliate programs.

=============READ ME BEFORE USE============

Hello,
For any issue contact: api@youtube6download.top

It is a beta version of my script.

Just download this php script.

// for downloading single video as mp3

Open index.php file
Look at the first line
// YOUTUBE VIDEO ID
$id = 'lF-jPBnZ098';

For converting multiple videos as MP3 file.
open multiple.php
// MULTIPLE YOUTUBE VIDEO ID's SEPARATED BY COMMNA (,)
$ids = 'lF-jPBnZ098,OmAlu5T44t8,GTJHrHHAElU';

All you need to do is to change the $id variable value with the desired video id that you want to download as mp3.
That's it!
If you have php installed on your server/localhost then you we'll get result on the webpage. 
